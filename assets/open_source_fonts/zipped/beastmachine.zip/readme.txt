This is Only for Personal Use. 

For commercial rights please contact us : thirtypath30@gmail.com

https://www.creativefabrica.com/product/beastmachine/ref/2195/

Regards, 
Thirtypath Studio.